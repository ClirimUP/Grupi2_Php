<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
       
     
        
    
        <link rel="stylesheet" href="CssChairmanPage.css"/>
    
    </head>
    <body>
        <div id="nav">
            <ul>
                <li><a href="../Home Page/HomePage.php">HOMEPAGE</a></li>
				<li><a href="../Results/ResultsPage.php">RESULTS</a></li>
				<li><a href="../Game/index.php">GAME</a></li>
				<li><a href="#dropdown">DROPDOWN</a></li>
				<li><a href="#gallery">GALLERY</a></li>
				<li><a href="#portfolio">PORTFOLIO</a></li>
				<li><a href="../Chairman/ChairmanPage.php">CHAIRMAN</a></li>
				<li><a href="#longlinktext">LONG LINK TEXT </a></li>
				<li><a href="../login.php">LOG IN</a></li>
            </ul>
        </div>
        <header>
            <h1><span >Chairman</span>  </h1>
            <nav id="mainContact">
                <ul>
                    <li><a href="#">CV</a></li>
                    <li><a href="#">Canvas</a></li>
                    <li><a href="#">Wallpapers</a></li>
                </ul>
            </nav>          
        </header>

        <article id="mainName" alt="Portrait">
            <div >
                <img src="images/GjonMili2.jpg" height="180" width="180">
                <h2 style="font-size: 30px;"> Gjon Mili </h2>
            </div>

            <section class="Personal">
                <h3 ><img src="images/Personal5.png" height="28" width="28"><a href="#" class="emojiPersonalinfo">Personal Info</a></h3>
                <p>
                    <a target="_blank" href="London.png">
                <img src="images/London.png" height="100" alt="London" usemap="#workmap" alt="London" width="170">
            </a>
                <map name="workmap">
                    <area shape="rect" coords="34, 44, 270" >
                </map>
                    <em>City:</em> London <br>
                    <em>Country:</em> England <br>
                    <em>Region:</em> LN <br>
                    <em>Postal:</em> WC2N 5DU <br>
                    <em>Address:</em> A4, London WC2N 5DU, UK <br>
                   
                </p>
            </section>

            <section class="Contact">
                
                <h3><img src="images/Contact.png" height="28" width="28"><a href="#" class="emojiContact">Contact</a></h3>
            
                <p>
                    
                    <em>Phone:</em> <a href="tel:+34557828814">+3 (455) 782-8814</a><br/>
                    <em>Tel Fix</em> <a href="tel:+707411505" >+707411505</a><br/>
                    <em>Email:</em> <a href="mailto: xhemailiadhurim@gmail.com" >xhemailiadhurim@gmail.com</a><br/>
                    <span style="cursor:wait">As soon as we can we will respond to you</span><br>
                    
                </p>
            </section>
            <section class="w3-container">
                <h4 style="font-size: 20px;">Here, his heart take a rest</h4>
                <figure>
                    <img src="images/GjonMili3.jpg" height="650" width="1000">
                </figure>
            </section>


        </article>
        <div class="w3-container"> 
            <h2>His Biography</h2>
            <p>Gjon Mili Biography
                Born in 1904 in Albania, Mili moved to America in 1923. He trained as an engineer and was self-taught in photography. He is most famous for his images that captured Picasso drawing with light.
                Mili attended MIT shortly after he moved to America, where worked with Professor Harold Edgerton utilizing electronic flash to refine strobe photography. 
                Since the late 1930s, he used a rapid-firing sequence technique in his photography, which allowed him to catch multiple images in a single frame.
                 His photographs of dance, athletics, and musical and theatrical performances were then able to show the graceful flow of movement too rapid for the naked eye to distinguish. 
                 In 1939, Mili became a freelance photographer working for LIFE Mili died at the age of 79 of pneumonia. His work changed contemporary visual understanding of movement,
                  and left a great precedence for all action photographers to follow. </p>
                     </div>

                     <section class="w3-container">
                        <h4 style="font-size: 20px;">Sharing his relation with Pablo Picasso</h4>
                        <figure>
                            <a target="_blank" href="images/GjonMili5.jpg">
                            <img src="images/GjonMili5.jpg" height="900" width="900">
                        </a>
                        </figure>
                        <div class="button2">
                        <button class="button1" onclick="document.getElementById('demo2').style.display='block'">More! </button>
                        <p id="demo2" style="display:none"> When LIFE magazine's Gjon Mili, a technical prodigy and lighting innovator, visited Pablo Picasso in the South of France in 1949, it was clear that the meeting of these two artists and craftsmen was bound to result in something extraordinary. Mili showed Picasso some of his photographs of ice skaters with tiny lights affixed to their skates, jumping in the dark — and the Spanish genius's ever-stirring mind began to race.
                            "Picasso" LIFE magazine reported at the time, "gave Mili 15 minutes to try one experiment. He was so fascinated by the result that he posed for five sessions, projecting 30 drawings of centaurs, bulls, Greek profiles and his signature. Mili took his photographs in a darkened room, using two cameras, one for side view, another for front view. By leaving the shutters open, he caught the light streaks swirling through space."
                            This series of photographs, known ever since as Picasso's "light drawings," were made with a small electric light in a darkened room; in effect, the images vanished as soon as they were created — and yet they still live, six decades later, in Mili's playful, hypnotic images. Many of them were also put on display in early 1950 in a show at New York's Museum of Modern Art.
                            Finally, while the "Picasso draws a centaur in the air" photo that leads off this gallery is rightly celebrated, many of the images in this gallery are far less well-known — in fact, many of them never ran in the magazine. But they are no less thrilling, after all these years, than the famous shot of the 20th century's archetypal creative genius crafting, on the fly, a simultaneously fleeting and enduring work of art.
                            A note on the last image in the gallery: An excerpt from a 1968 special issue of LIFE, devoted entirely to Picasso, describes a typical scene at his home: "Putting on a mask is sometimes enough to set Picasso off into a kind of witch-doctor frenzy. He roars and writhes behind his gorilla mask, dances away to the mirror, returns in a rubber devil's mask to swoop down on his daughter Paloma. Picasso was one of the first European artists to recognize the magic and beauty of African masks,
                             and his own masks show the enduring power of that early influence."</p>
                            </div>
                    </section>

                    <section class="w3-container">
                        <h4 style="font-size: 20px;">He was in love with her cat</h4>
                        <figure>
                            <a target="_blank" href="images/GjonMili6.jpg">
                            <img src="images/GjonMili6.jpg" height="900" width="900">
                        </a>
                        </figure>

                        <p> He was knwon for his best pics of cats, specially when he was taking photo to her cat</p>
                    </section>

                    
                      </style>
                      <div class="klasa">
                      <button class="button" onclick="document.getElementById('demo').innerHTML=Date()">Time Is:</button>
                      

                        <p id="demo">
                            
                        </p>
                        
                    </div>
                      </head>
                      <body>
                      
                        
                        
          
        <footer>
            <p><a href="#">Admin Stuffe's</a></p>
            <p id="copyright">Copyright &copy;  Creative Commons Attribution-ShareAlike License </p>
        </footer>
    </body>
</html>